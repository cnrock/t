#!/bin/bash
shijiancuo=$(date '+%Y-%m-%d-%H')
list=$(cat /root/reg-ns-list.txt)
reg_ip=10.23.101.18
reg_user=admin
reg_passwd=changeme
reg_container=$(kubectl get po -n kube-system|grep registry|grep "1/1     Running"|awk '{print $1}'|head -n1)
for kongjian in $list
do
bash -x  /root/gc-registry-prefix.sh -h "https://$reg_ip" -a "$reg_user:$reg_passwd"  -p "count=2" -n $kongjian >> /var/log/img-prefix-match-$shijiancuo.log 2>>/var/log/img-clean-$shijiancuo.log
echo "clean $kongjian was done,thanks"
sleep 5
# if dce 2...
docker exec -it dce_controller_1 registry garbage-collect /etc/docker/registry/conf.yml >> /var/log/img-gc-$shijiancuo.log 2>&1
# if dce 3...
docker exec -it dce_registry_1 registry garbage-collect /etc/docker/registry/conf.yml >> /var/log/img-gc-$shijiancuo.log 2>&1
# if dce 4...
kubectl exec -it -n kube-system $reg_container  registry garbage-collect /etc/docker/registry/conf.yml >> /var/log/img-gc-$shijiancuo.log 2>&1
sleep 5
echo "garbage-collect was done,thanks"
done
